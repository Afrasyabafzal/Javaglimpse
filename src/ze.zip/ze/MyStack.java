package ze;

public class MyStack {

}
