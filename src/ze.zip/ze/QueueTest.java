package ze;

import static org.junit.Assert.*;

import java.util.NoSuchElementException;
 
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import org.junit.Test;

public class QueueTest {
	
	private Queue obj =new Queue(20);

	@Before
	public void Enqueue() throws Exception
	{
		obj.enqueue(4);
		obj.enqueue(6);
		obj.enqueue(2);
		
	}
	@Test
	public void testEnqueue() {
		int expectedarr[]= {4,6,2};
		assertEquals(expectedarr.length,obj.sizeofQueue);
		for(int i=0;i<expectedarr.length;i++)
			assertEquals(expectedarr[i],obj.array[i]);
			
	}

	@Test
	public void testDequeue() throws Exception {
		assertEquals(4,obj.dequeue());
	}

	@Test
	public void testEmpty() {
		assertFalse(obj.empty());
	}

	@Test
	public void testSize() {
		assertEquals(3,obj.size());
	}

}
